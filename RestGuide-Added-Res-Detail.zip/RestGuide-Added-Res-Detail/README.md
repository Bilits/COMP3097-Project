Before Running the project run the following command to install Pod 

$ sudo gem install cocoapods
$ pod install